#!/bin/bash


sys_user=$(echo $SysUser|awk '{print $1}')
sys_pass=$(echo $SysUser|awk '{print $2}')

function start_console() {
    consoles -i 127.0.0.1 -p 5000 -d 0 -T xterm env_login &
}

function start_nginx() {
    cd /etc/nginx && openssl req -x509 -nodes -days 7305 -newkey rsa:2048 -keyout nginx.key -out nginx.crt -subj "/CN=local" >/dev/null 2>&1
    exec nginx -g 'daemon off;'
}

function main() {
    useradd -m -s /bin/bash -G wheel $sys_user
    echo "$sys_pass" | passwd --stdin $sys_user
    
    start_console
    sleep 0.2
    start_nginx
}

main

exec $@


